<?php
/**
 * PHPMailer language file.  
 * Hungarian Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Meg kell adnod legal�bb egy ' .
                                     'c�mzett email c�met.';
$PHPMAILER_LANG["mailer_not_supported"] = ' levelez� nem t�mogatott.';
$PHPMAILER_LANG["execute"] = 'Nem tudtam v�grehajtani: ';
$PHPMAILER_LANG["instantiate"] = 'Nem siker�lt p�ld�nyos�tani a mail funkci�t.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Hiba: Sikertelen autentik�ci�.';
$PHPMAILER_LANG["from_failed"] = 'Az al�bbi Felad� c�m hib�s: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Hiba: Az al�bbi ' .
                                       'c�mzettek hib�sak: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Hiba: Nem elfogadhat� adat.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Hiba: Nem tudtam csatlakozni az SMTP host-hoz.';
$PHPMAILER_LANG["file_access"] = 'Nem siker�lt el�rni a k�vetkez� f�jlt: ';
$PHPMAILER_LANG["file_open"] = 'F�jl Hiba: Nem siker�lt megnyitni a k�vetkez� f�jlt: ';
$PHPMAILER_LANG["encoding"] = 'Ismeretlen k�dol�s: ';
?>