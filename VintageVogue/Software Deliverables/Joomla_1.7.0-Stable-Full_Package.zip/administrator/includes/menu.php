<?php
/**
 * @version		$Id: menu.php 21097 2011-04-07 15:38:03Z dextercowley $
 * @copyright	Copyright (C) 2005 - 2011 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

/**
 * JMenu class.
 *
 * @package		Joomla.Administrator
 * @subpackage	Application
 * @since		1.5
 */
class JMenuAdministrator extends JMenu
{

}
