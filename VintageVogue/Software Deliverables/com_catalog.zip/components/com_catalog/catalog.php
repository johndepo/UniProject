<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller'); //importing controller class (we are calling controller class directly, the controller file in our component)

$controller = JController::getInstance('Catalog'); //gets controller class with prefix 'Catalog' in it and creates instance
$controller->execute(JRequest::getCmd('task')); //parse 'task' value to controller, task is just naming convention (eg in browser: '/joomla/index.php?option=com_explore&task=save', where save is a method in your  Explore controller)
$controller->redirect(); //redirct to other page (upon execute completion)