<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller'); //importing libraray with controller code to jimport function

class CatalogController extends JController //
{
	public function save()
	{
		echo "saving tour...";
	}

	public function delete()
	{
		echo "deleting tour...";
	}
}