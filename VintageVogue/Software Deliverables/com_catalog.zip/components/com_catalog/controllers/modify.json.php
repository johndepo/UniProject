<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller');

class CatalogControllerModify extends JController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->registerTask('change', 'setSold');
	}

	public function setSold()
	{ 
		//http://localhost/joomla/index.php/catalogue?option=com_catalog&task=modify.change&format=json&goods_id=1&tmpl=raw
		//goods_id=1 is the one your gonna set to sold
		$task = $this->getTask();
		$goods_id = JRequest::getInt('goods_id', 0); //grab selected value from front(?)

		$goods_status = 1; //0 is available, 1 is purchased, 2 is sent to buyer (done in backend manually)
		$published = 0;
		$model = $this->getModel('Modify'); //create the model from Modify table

		if($task == 'change') 
		{
			echo json_encode(array('Item has been successfully purchased' => $model));
			$model->editStatus($goods_id, $published, $goods_status);
		} 
		else
		{
			echo json_encode(array('Sale was interrupted in PayPal' => 'error'));
		}
		
	}
}
