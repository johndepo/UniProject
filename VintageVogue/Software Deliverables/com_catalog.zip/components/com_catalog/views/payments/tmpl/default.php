<?php 
defined( '_JEXEC' ) or die;
$document = JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'components\com_catalog\views\payments\tmpl\payment.css'); 
?>
<h1><?php echo $this->header ?></h1>

<body>
    <center class = "Contents">
	<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_xclick"> 
		<input type="hidden" name="business" value="anonim_1315287428_biz@gmail.com"> 
		
		<div class="lblItem">Item:</div>
		<div class = "itemValues"><input type="text" readonly = "readonly" size="30" maxlength="32" name="item_name" value="<?php echo $this->item->goods_name ?>"/>
		
		<div class="lblPrice">Price:</div>
		<div class="priceValue"><input type="text" readonly = "readonly" name="amount" size="5" maxlength="32" value="<?php echo $this->item->goods_price ?>" /></div>
	
		<div class = "something"><input type="hidden" size="3" maxlength="32" name="quantity" value="1"/></div>
		
		<div class = "lblCurrency">Currency: <br /> </div>
		<div class = "currencySelection"><select name="currency_code">
					<option value="USD">USD</option>
					<option value="GBP">GBP</option>
					<option value="EUR">EUR</option>
					<option value="JPY">JPY</option>
					<option value="CAD">CAD</option>
					<option value="AUD" SELECTED>AUD</option>
					</select></div>
		
		
		<div class = "lblFirstName">First Name:</div>
		<div class = "firstNameValue"><input type="text" size="30" maxlength="32" name="first_name" value="" /></div>
		
		
		<div class = "lblSurname">Surname:</div>
		<div class = "surnameValue"><input type="text" size="30" maxlength="32" name="last_name" value="" /></div>
		
		
		<div class = "lblAddress">Address: </div>
		<div class = "addressValue"><input type="text" size="30" maxlength="32" name="address1" value="" /</div>
		
		<div class = "lblCity">City: </div>
		<div class = "cityValue"><input type="text" size="30" maxlength="32" name="city" value="" /></div>
		<div>			
		
		<div class = "lblState">State: </div>
		<div class = "stateValue"><input type="text" size="30" maxlength="32" name="state" value="" /></div>
		
		<div class = "lblCountry">Country: </div>
		<div class = "countryValue"><input type="text" size="30" maxlength="32" name="country" value="" /></div>
		
		<div class = "lblZipCode">Zip Code: </div>
		<div class = "zipCodeValue"><input type="text" size="30" maxlength="32" name="zip" value="" /></div>
		
		<div class = "btnPayPal">
			<input type="image" src="https://www.sandbox.paypal.com/en_AU/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal ? The safer, easier way to pay online.">
			<img alt="" border="0" src="https://www.sandbox.paypal.com/en_AU/i/scr/pixel.gif" width="1" height="1">
			<?php $url = 'index.php?option=com_catalog&task=modify.change&format=json&goods_id=' . $this->item->goods_id . '&tmpl=raw'; ?>
						
			<!--?php echo $url?>"-->
			<a class= "manualSold"href="<?php echo JRoute::_($url); ?>"><?php echo "Sell Item (If PayPal not connected)" ?></a>
		</div>
	</form>
    </center>
</body>

</div>




