<?php 
defined( '_JEXEC' ) or die; 
$document = JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'components\com_catalog\views\productDetails\tmpl\productDetails.css');
?>

<h1 class="goodsName"><?php echo $this->escape($this->item->goods_name) ?></h1>

<div class="goodsInformation">
	<div class="goodsImage">
	<img src = "http://localhost/root/<?php echo $this->item->goods_image?>"width="200" height="160" border="0"/>
	</div>
		
	<div class="goodsPrice">
	<?php echo JText::_('Price: $') ?><?php echo $this->item->goods_price ?>
	</div>
	
	<div class="goodsDetailsTitle">
	<?php echo JText::_('Details: ') ?>
	<?php echo $this->item->goods_notes ?>
	</div>
				
	<div class="goodsCatagoryTitle">
	<?php echo JText::_('Catagory: ') ?>
	<?php echo $this->item->goods_category ?>
	</div>
				
	<div class="goodsColourTitle">
	<?php echo JText::_('Colour: ') ?>
	<?php echo $this->item->goods_colour ?>
	</div>
	
	<div class="goodsSizeTitle">
	<?php echo JText::_('Size: ') ?>
	<?php echo $this->item->goods_size ?>
	</div>
	
	<div class="purchaseGood">
	<?php $url = 'index.php?option=com_catalog&view=payments&id=' . $this->item->goods_id; ?>
	<a href="<?php echo JRoute::_($url); ?>"><?php echo "Purchase Item" ?></a>
	</div>
</div>




