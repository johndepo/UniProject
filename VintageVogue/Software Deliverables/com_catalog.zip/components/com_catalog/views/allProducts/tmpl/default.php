<?php 
defined( '_JEXEC' ) or die; 
$document = JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'components\com_catalog\views\allProducts\tmpl\allProducts.css');
?>

<h1><?php echo $this->header ?></h1>


<?php $txt="http://localhost/Joomla/"; ?>

<?php foreach ($this->items as $i => $item): ?>
<?php $url = 'index.php?option=com_catalog&view=productDetails&id=' . $item->goods_id; ?>
	<div class="productDetail">
		<!--?php echo $url?>"-->
		<?php $url = 'index.php?option=com_catalog&view=productDetails&id=' . $item->goods_id; ?>
		<div class="image"><a href="<?php echo JRoute::_($url); ?>"><img src = "http://localhost/root/<?php echo ($this->escape($item->goods_image))?>"width="200" height="160" border="0"/></a></div>
		
		<div class="productName"><?php echo $this->escape($item->goods_name) ?></div>
		<div class="productDescription"><?php echo $this->escape($item->goods_notes) ?></div>
		<div class="price"><?php echo JText::_('Price: $') ?><?php echo $this->escape($item->goods_price) ?></div>
	</div>
<?php endforeach ?>