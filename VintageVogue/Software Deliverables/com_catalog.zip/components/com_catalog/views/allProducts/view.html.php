<?php
//This code file is run first before the default.php in the tmpl folder
//if you want to add data, put some code here
//the default.php file is essentially what will be displayed in the front end
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');

class CatalogViewAllProducts extends JView //Catalog is name of component, AllProducts is name of view
{
	protected $header;
	protected $items;

	public function display($tpl = null)
	{
		$this->header = 'Products List';
		$this->items = $this->get('Items');

		parent::display($tpl);
	}
}