<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.model');

class CatalogModelPayments extends JModel
{
	public function getItem()
	{
		$product_id = JRequest::getInt('id');

		$row = JTable::getInstance('payments', 'CatalogTable');
		$row->load($product_id);

		return $row;
	}
}