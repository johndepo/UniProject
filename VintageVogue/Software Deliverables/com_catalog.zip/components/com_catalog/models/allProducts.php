<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.modellist');

class CatalogModelAllProducts extends JModelList
{
	public function getListQuery()
	{
		$query = parent::getListQuery();

		$query->select('goods_id, goods_name, goods_price, goods_image, goods_status');
		$query->from('#__catalogue_goods')
				->where('published = 1');

		return $query;
	}
}
