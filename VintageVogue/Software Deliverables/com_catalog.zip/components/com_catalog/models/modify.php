<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.modellist');

class CatalogModelModify extends JModelList
{
	//for adding shit in the front end later (more arguments after $goods_id)
	public function editStatus($goods_id, $published, $goods_status)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		$query->update('#__catalogue_goods');
		$query->set('published = ' . $published); //this is our goods status option
		$query->set('goods_status = ' . $goods_status); //this is our goods status option
		$query->where('goods_id = ' . $goods_id); //this is our goods_id


		$db->setQuery($query)->query();
	}
}