<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.model');

class CatalogModelProductDetails extends JModel
{
	public function getItem()
	{
		$product_id = JRequest::getInt('id');

		$row = JTable::getInstance('productDetails', 'CatalogTable');
		$row->load($product_id);

		return $row;
	}
}