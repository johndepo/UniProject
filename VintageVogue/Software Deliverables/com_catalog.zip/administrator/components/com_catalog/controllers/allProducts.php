<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controlleradmin');

class CatalogControllerAllProducts extends JControllerAdmin
{
	protected $text_prefix = 'Product';

	public function getModel($name = 'ProductDetails', $prefix = 'CatalogModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);

		return $model;
	}
}