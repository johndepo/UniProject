<?php
defined( '_JEXEC' ) or die;
//this has been defined for the adding, editing and deleting of backend records
jimport('joomla.application.component.controllerform');

class CatalogControllerProductDetails extends JControllerForm
{
	protected $view_list = 'allProducts'; //what listview we using
}