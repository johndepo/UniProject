<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.modeladmin');

class CatalogModelProductDetails extends JModelAdmin
{
	public function getTable($type = 'ProductDetails', $prefix = 'CatalogTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	
	protected function loadFormData()
	{
		$data = JFactory::getApplication()->getUserState('com_catalog.edit.productDetails.data', array());

		if (empty($data)) {
			$data = $this->getItem();
		}

		return $data;
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_catalog.productDetails', 'productDetails', array('control' => 'jform', 'load_data' => $loadData));

		return $form;
	}
}
