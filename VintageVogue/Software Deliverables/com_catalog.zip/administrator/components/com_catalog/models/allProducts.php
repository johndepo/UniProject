<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.modellist');

class CatalogModelAllProducts extends JModelList
{
	public function getItems()
	{
		$items = parent::getItems();

		foreach ($items as &$item) {
			$item->url = 'index.php?option=com_catalog&amp;task=productDetails.edit&amp;goods_id=' . $item->goods_id;
		}

		return $items;
	}

	public function getListQuery()
	{
		$query = parent::getListQuery();

		$query->select('*');
		$query->from('#__catalogue_goods');

		return $query;
	}
}