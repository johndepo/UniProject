CREATE TABLE `#__catalogue_goods` (
	`goods_id` int(20) NOT NULL AUTO_INCREMENT,
	`goods_image` varchar(1025) NOT NULL,
	`goods_name` varchar(255) NOT NULL,
	`goods_price` int(20) NOT NULL,
	`goods_status` varchar(255) NOT NULL,
	`goods_category` varchar(255) NOT NULL,
	`goods_size` varchar(255) NOT NULL,
	`goods_colour` varchar(255) NOT NULL,
	`goods_notes` varchar(255) NOT NULL,
	`goods_alias` varchar(255) NOT NULL,
	`published` int(4) NOT NULL,
	PRIMARY KEY (`goods_id`)
)ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;

CREATE TABLE `#__catalogue_st` (
	`st_id` int(20) NOT NULL AUTO_INCREMENT,
	`st_name` varchar(255) NOT NULL,
	`st_price` int(20) NOT NULL,
	`st_status` varchar(255) NOT NULL,
	`st_notes` int(20) NOT NULL,
	`st_alias` varchar(255) NOT NULL,
	`published` int(4) NOT NULL,
	PRIMARY KEY (`st_id`)
)ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;