<?php
defined( '_JEXEC' ) or die;

class CatalogTablePayments extends JTable
{
	//easy referencing without sql
	public function __construct(&$db)
	{
		parent::__construct('#__catalogue_goods', 'goods_id', $db);
	}
}
