<?php
defined( '_JEXEC' ) or die;

class CatalogTableModify extends JTable
{
	public function __construct(&$db)
	{
		parent::__construct('#__catalogue_goods', 'goods_id', $db);
	}
}
