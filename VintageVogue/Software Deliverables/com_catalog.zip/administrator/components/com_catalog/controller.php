<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller');

class CatalogController extends JController
{
}