<?php defined( '_JEXEC' ) or die; ?>
<form action="index.php?option=com_catalog&amp;view=allProducts" method="post" name="adminForm" id="adminForm">

	<table class="adminlist">
		<thead>
			<tr>
				<th width="1%">
					<input type="checkbox" name="checkall-toggle" value="" onclick="checkAll(this)" />
				</th>
				<th><?php echo JText::_('Product') ?></th>
				<th><?php echo JText::_('Price') ?></th>
				<th><?php echo JText::_('Status') ?></th>
				<th><?php echo JText::_('Published') ?></th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="4">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php foreach ($this->items as $i => $item): ?>
				<tr class="row<?php echo $i % 2 ?>">
					<td class="center">
						<?php echo JHtml::_('grid.id', $i, $item->goods_id); ?>
					</td>
					<td>
						<a href="<?php echo $item->url; ?>">
						<?php echo $this->escape($item->goods_name) ?></a>
					</td>
					<td><?php echo $this->escape($item->goods_price) ?></td>
					<td>
						<?php 
						if(($item->goods_status) == '0' || ($item->goods_status) == 'Available')
						{
							echo 'Available';
						}
						
						if(($item->goods_status) == '1' || ($item->goods_status) == 'Purchased')
						{
							echo 'Purchased';
						}
						
						if(($item->goods_status) == '2' || ($item->goods_status) == 'sold')
						{
							echo 'Sent to Buyer';
						}
						?>
					</td>
					<td class="center">
						<?php echo JHtml::_('jgrid.published',$item->published, $i, 'allProducts.', true, 'cb'); ?> <!--AllProducts is name of class file suffix in model-->
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo JHtml::_('form.token'); ?>
</form>