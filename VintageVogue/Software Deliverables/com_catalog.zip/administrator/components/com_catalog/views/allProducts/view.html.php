<?php
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');

class CatalogViewAllProducts extends JView
{
	protected $items;
	protected $pagination;

	public function display($tpl = null)
	{
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		
		$this->addToolbar();

		parent::display($tpl);
	}
	
	public function addToolbar()
	{
		JToolBarHelper::title(JText::_('Product Details'));

		JToolBarHelper::addNew('productDetails.add');
		JToolBarHelper::editList('productDetails.edit');

		JToolBarHelper::divider();

		JToolBarHelper::publishList('allProducts.publish');
		JToolBarHelper::unpublishList('allProducts.unpublish');

		JToolBarHelper::divider();

		JToolBarHelper::archiveList('allProducts.archive');

		JToolBarHelper::trash('allProducts.trash');
	}
}