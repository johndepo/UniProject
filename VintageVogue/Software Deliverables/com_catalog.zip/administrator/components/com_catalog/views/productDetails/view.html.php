<?php
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');

class CatalogViewProductDetails extends JView
{
	protected $item;
	protected $form;

	public function display($tpl = null)
	{
		$this->item = $this->get('Item');
		$this->form = $this->get('Form');

		$this->addToolbar();

		parent::display($tpl);
	}

	public function addToolbar()
	{
		if ($this->item->goods_id) //this is only used when we are editing a product
		{
			JToolBarHelper::title(JText::_('Edit Product'));
		} else {
			JToolBarHelper::title(JText::_('Add Product')); //adding product does not need id reference
		}

		JToolBarHelper::apply('productDetails.apply', 'JTOOLBAR_APPLY');
		JToolBarHelper::save('productDetails.save', 'JTOOLBAR_SAVE');
		JToolBarHelper::save2new('productDetails.save2new', 'JTOOLBAR_SAVE_AND_NEW');

		JToolBarHelper::cancel('productDetails.cancel');
	}
}