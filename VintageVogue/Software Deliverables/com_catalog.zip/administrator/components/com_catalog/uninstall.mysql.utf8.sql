DROP TABLE `#__catalogue_goods`;
DROP TABLE `#__catalogue_st`;
